import streamlit as st
from agent.dataagent import CSVDataAgent, i_query

st.title("CSV Data Agent")

uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])

if uploaded_file:
    agent = CSVDataAgent(uploaded_file)
    query = st.text_input("what is your question:")
    
    if query:
        answer = i_query(query, agent)
        st.write( "Answer:")
        st.write(answer)
