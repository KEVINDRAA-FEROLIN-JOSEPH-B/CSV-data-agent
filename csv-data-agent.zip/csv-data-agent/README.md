This is a simple AI bot 
which answers for the questions that are related to the CSV file that have been created . 

