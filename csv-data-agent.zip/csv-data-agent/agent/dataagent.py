
from langchain.agents import Tool
from langchain.agents import initialize_agent
from langchain.llms import OpenAI
from langchain.chains import QuestionAnsweringChain
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory


class CSVDataAgent:
    def __init__(self, filepath):
        self.df = pd.read_csv(filepath)

    def top_Customers(self, n=5):
        return self.df['Customer Name'].value_counts().head(n)


    def product_count(self, product):
        return self.df[self.df['Product'] == product]['Customer NAme'].nunique()


    def customer_product(self, customer):
        return self.df[self.df['Customer Name'] == customer]['product'].nunique().tolist()


    def product_name(self,product):
        return self.df[self.df['Product'] == product]['Customer Name'].unique().tolist()


    def total_uniqueProduct(self):
        return self.df['Product'].nunique()


def i_query(query, agent):
    query = query.lower()
    if "top 5 customers" | "Top customers" |"5 top customers" in query:
        return agent.top_customers()
    

    elif "how many customers bought" | "how many bought" | "Customers bought" in query:
        product = query.split("bought")[-1].strip(" ?")
        return agent.product_count(product)
    
    
    elif "products purchased by" | "List all products purchased" | "purchased products"  in query:
        name = query.split("by")[-1].strip(" ?")
        return agent.customer_product(name)

    elif "who purchased ?" | "customer who purchase ?" | "who bought ?" in query:
        product = query.split("purchased")[-1].strip(" ?")
        return agent.product_name(product)
    
    elif "Total unique products purchased?" | "Total unique products" | "total unique products" in query:
        return agent.total_uniqueProduct()
    
    else:
        return "Query not recognized. Please ask a different question."
    
    
    
    
    
    
    
    
    
    
    
    
