CSV based data agent 
 
1. dataagent.py 
    imports the csv file from tha customer_data.csv by using the pandas 

2. Interpreted aprroach 
    - The data is parsed line-by-line 
    - for fast and light approach 

3. LLM used - openAI 
    libaries used - langchain 
